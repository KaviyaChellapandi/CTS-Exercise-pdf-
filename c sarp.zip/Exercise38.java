public class Exercise38 {
    public static void main(String[] args) {
        System.out.println("This is Exercise 38.");
    }
}