public class Exercise12 {
    public static void main(String[] args) {
        System.out.println("This is Exercise 12.");
    }
}